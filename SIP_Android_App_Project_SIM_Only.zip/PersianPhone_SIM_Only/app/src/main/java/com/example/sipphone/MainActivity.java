package com.example.sipphone;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int CALL_PERMISSION_REQUEST = 77;
    private EditText numberField;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(246, 248, 247));

        TextView title = new TextView(this);
        title.setText("تماس سیم‌کارتی");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.rgb(18, 55, 42));
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("شماره را وارد کن و دکمه تماس را بزن");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = matchWrap();
        subParams.topMargin = dp(12);
        root.addView(subtitle, subParams);

        numberField = new EditText(this);
        numberField.setSingleLine(true);
        numberField.setTextSize(25);
        numberField.setGravity(Gravity.CENTER);
        numberField.setHint("مثلاً 09123456789");
        numberField.setInputType(InputType.TYPE_CLASS_PHONE);
        numberField.setPadding(dp(12), dp(16), dp(12), dp(16));
        numberField.setBackground(roundBg(Color.WHITE, Color.rgb(190, 205, 197), 14));
        LinearLayout.LayoutParams inputParams = matchWrap();
        inputParams.topMargin = dp(36);
        root.addView(numberField, inputParams);

        Button callButton = new Button(this);
        callButton.setText("تماس با سیم‌کارت  ☎");
        callButton.setTextSize(18);
        callButton.setTextColor(Color.WHITE);
        callButton.setAllCaps(false);
        callButton.setBackground(roundBg(Color.rgb(8, 127, 91), Color.rgb(8, 127, 91), 16));
        LinearLayout.LayoutParams callParams = matchWrap();
        callParams.topMargin = dp(24);
        root.addView(callButton, callParams);
        callButton.setOnClickListener(v -> startCall());

        Button dialerButton = new Button(this);
        dialerButton.setText("باز کردن شماره‌گیر گوشی");
        dialerButton.setTextSize(16);
        dialerButton.setAllCaps(false);
        LinearLayout.LayoutParams dialParams = matchWrap();
        dialParams.topMargin = dp(8);
        root.addView(dialerButton, dialParams);
        dialerButton.setOnClickListener(v -> openDialer());

        TextView note = new TextView(this);
        note.setText("این نسخه فقط از تماس معمولی سیم‌کارت استفاده می‌کند؛ تماس اینترنتی SIP ندارد. ممکن است گوشی برای انتخاب سیم‌کارت از تو تأیید بخواهد.");
        note.setTextSize(13);
        note.setTextColor(Color.GRAY);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteParams = matchWrap();
        noteParams.topMargin = dp(28);
        root.addView(note, noteParams);

        setContentView(root);
    }

    private void startCall() {
        String number = numberField.getText().toString().trim();
        if (number.isEmpty()) {
            numberField.setError("شماره تلفن را وارد کن");
            return;
        }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, CALL_PERMISSION_REQUEST);
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.fromParts("tel", number, null));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "تماس شروع نشد؛ از شماره‌گیر گوشی استفاده کن.", Toast.LENGTH_LONG).show();
            openDialer();
        }
    }

    private void openDialer() {
        String number = numberField.getText().toString().trim();
        Intent intent = new Intent(Intent.ACTION_DIAL);
        if (!number.isEmpty()) intent.setData(Uri.fromParts("tel", number, null));
        startActivity(intent);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CALL_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCall();
            else Toast.makeText(this, "برای تماس مستقیم باید اجازه تماس را بدهی؛ یا شماره‌گیر گوشی را باز کن.", Toast.LENGTH_LONG).show();
        }
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable roundBg(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), stroke); return d;
    }
}
